Progress:
- Auth HMAC SHA-256
- Time Stamp field db, Challenge response Time limit, Challenge response deletion after used
- Ip Address Log, Errot handling config, Json Format check
- 3 new Bot Conversation endpoints
- Header hash validation from request, connection to real backend
- Uniqe user_id field and implement Upsert challenge_response and session